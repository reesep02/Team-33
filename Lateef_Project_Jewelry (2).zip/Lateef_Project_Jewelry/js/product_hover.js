function mouseHover(){
    var product = document.getElementsByClassName("product-description")
    for (let index = 0; index < product.length; index++) {
        product[i].style.display = "block"
        
    }
   
}